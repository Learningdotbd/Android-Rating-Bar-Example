package com.ldb.learninddotbd;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RatingBar ratingbar_id;
    Button button;
    TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addListenerOnButtonClick();
    }

    public void addListenerOnButtonClick() {
        ratingbar_id = (RatingBar) findViewById(R.id.ratingbar_id);
        button = (Button) findViewById(R.id.button);
        text = findViewById(R.id.text);
        //Performing action on Button Click
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                //Getting the rating and displaying it on the toast
                String rating = String.valueOf(ratingbar_id.getRating());
                Toast.makeText(getApplicationContext(), "OK", Toast.LENGTH_LONG).show();

            }


        });

        ratingbar_id.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                String rating = String.valueOf(ratingbar_id.getRating());
                text.setText("Value: " + rating);
            }
        });
    }
}

// Thanks for visiting Learning dot bd